package com.example.spring_sql_webhook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSqlWebhookApplicationTests {

	@Test
	void contextLoads() {
	}

}
